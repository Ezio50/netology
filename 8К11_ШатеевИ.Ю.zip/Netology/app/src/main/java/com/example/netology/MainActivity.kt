package com.example.netology
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Handler(Looper.getMainLooper()).postDelayed({
                    }, 3000)
        val startButton: Button = findViewById(R.id.startButton)
        startButton.setOnClickListener {
            startActivity(Intent(this, MainMenuActivity::class.java))
            finish()
        }

        val statsButton: Button = findViewById(R.id.statsButton)
        statsButton.setOnClickListener {
            startActivity(Intent(this, GameStatsActivity::class.java))
        }
    }
}
