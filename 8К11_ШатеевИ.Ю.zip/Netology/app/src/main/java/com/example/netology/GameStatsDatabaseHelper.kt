package com.example.netology
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class GameStatsDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "game_stats.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "game_stats"
        private const val COLUMN_ID = "id"
        private const val COLUMN_TOTAL_TAPS = "total_taps"
        private const val COLUMN_HITS = "hits"
        private const val COLUMN_ACCURACY = "accuracy"
        private const val COLUMN_GAME_TIME = "game_time"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableQuery = ("CREATE TABLE $TABLE_NAME ("
                + "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "$COLUMN_TOTAL_TAPS INTEGER, "
                + "$COLUMN_HITS INTEGER, "
                + "$COLUMN_ACCURACY REAL, "
                + "$COLUMN_GAME_TIME INTEGER)")
        db.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun insertGameResult(totalTaps: Int, hits: Int, accuracy: Double, gameTime: Long) {
        val db = this.writableDatabase

        val selectQuery = "SELECT * FROM $TABLE_NAME WHERE $COLUMN_TOTAL_TAPS = ? AND $COLUMN_HITS = ? AND $COLUMN_ACCURACY = ? AND $COLUMN_GAME_TIME = ?"
        val cursor = db.rawQuery(selectQuery, arrayOf(totalTaps.toString(), hits.toString(), accuracy.toString(), gameTime.toString()))

        if (!cursor.moveToFirst()) {
            val values = ContentValues().apply {
                put(COLUMN_TOTAL_TAPS, totalTaps)
                put(COLUMN_HITS, hits)
                put(COLUMN_ACCURACY, accuracy)
                put(COLUMN_GAME_TIME, gameTime)
            }
            db.insert(TABLE_NAME, null, values)
        }

        cursor.close()
        db.close()
    }

    fun getLast10Games(): List<GameResult> {
        val gameList = mutableListOf<GameResult>()
        val db = this.readableDatabase
        val selectQuery = "SELECT * FROM $TABLE_NAME ORDER BY $COLUMN_ID DESC LIMIT 10"
        val cursor = db.rawQuery(selectQuery, null)

        if (cursor.moveToFirst()) {
            do {
                val totalTaps = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_TOTAL_TAPS))
                val hits = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_HITS))
                val accuracy = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_ACCURACY))
                val gameTime = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_GAME_TIME))
                gameList.add(GameResult(totalTaps, hits, accuracy, gameTime))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return gameList
    }
}

data class GameResult(val totalTaps: Int, val hits: Int, val accuracy: Double, val gameTime: Long)
