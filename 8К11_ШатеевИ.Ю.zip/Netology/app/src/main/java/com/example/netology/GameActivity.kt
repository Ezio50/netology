package com.example.netology

import android.annotation.SuppressLint
import android.graphics.Rect
import android.media.MediaPlayer
import android.os.Bundle
import android.os.SystemClock
import android.view.MotionEvent
import android.widget.ImageView
import android.widget.TextView
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import kotlin.random.Random
import android.view.View

class GameActivity : AppCompatActivity() {
    private lateinit var gameLayout: ConstraintLayout
    private lateinit var hitCounter: TextView
    private lateinit var endGameButton: Button
    private var totalTaps = 0
    private var hits = 0
    private var mice = mutableListOf<ImageView>()
    private var startTime: Long = 0
    private lateinit var dbHelper: GameStatsDatabaseHelper
    private var isGameFinished = false

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        dbHelper = GameStatsDatabaseHelper(this)
        gameLayout = findViewById(R.id.gameLayout)
        hitCounter = findViewById(R.id.hitCounter)
        endGameButton = findViewById(R.id.endGameButton)

        val speed = intent.getIntExtra("speed", 3)
        val size = intent.getIntExtra("size", 3)
        val miceCount = intent.getIntExtra("miceCount", 1)

        for (i in 0 until miceCount) {
            val mouse = ImageView(this).apply {
                setImageResource(R.drawable.mouse_image) // Заменить на изображение мышки
                layoutParams = ConstraintLayout.LayoutParams(size * 100, size * 100)
            }
            gameLayout.addView(mouse)
            mice.add(mouse)

            // Старт анимации движения
            startTime = SystemClock.uptimeMillis()
            startMouseAnimation(mouse, speed)
        }

        // Обработчик касаний
        gameLayout.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {  // Срабатывает только при первом касании
                totalTaps++
                for (mouse in mice) {
                    if (isHit(mouse, event)) {
                        hits++
                        updateHitCounter() // Обновляем счетчик попаданий
                        playMouseSound()

                        // Мышка пропадает и через некоторое время появляется снова
                        mouse.visibility = View.INVISIBLE
                        mouse.postDelayed({
                            mouse.visibility = View.VISIBLE
                            startMouseAnimation(mouse, speed)
                        }, 1000)
                    }
                }
            }
            true
        }

        endGameButton.setOnClickListener {
            finishGame() // Завершение игры по нажатию кнопки
        }
    }

    private fun showMouseAfterDelay(mouse: ImageView, speed: Int, delay: Long) {
        mouse.postDelayed({
            mouse.visibility = ImageView.VISIBLE
            startMouseAnimation(mouse, speed)
        }, delay)
    }

    private fun hideMouse(mouse: ImageView) {
        mouse.visibility = ImageView.INVISIBLE
        mouse.clearAnimation()
    }

    private fun startMouseAnimation(mouse: ImageView, speed: Int) {
        if (gameLayout.width > 0 && gameLayout.height > 0 && mouse.width > 0 && mouse.height > 0) {
            val randomX = Random.nextInt(0, gameLayout.width - mouse.width)
            val randomY = Random.nextInt(0, gameLayout.height - mouse.height)

            mouse.animate()
                .x(randomX.toFloat())
                .y(randomY.toFloat())
                .setDuration((5000 / speed).toLong())
                .withEndAction {
                    startMouseAnimation(mouse, speed)
                }
                .start()
        } else {
            mouse.postDelayed({
                startMouseAnimation(mouse, speed)
            }, 100)
        }
    }

    private fun isHit(mouse: ImageView, event: MotionEvent): Boolean {
        val hitRect = Rect()
        mouse.getHitRect(hitRect)
        return hitRect.contains(event.x.toInt(), event.y.toInt())
    }

    private fun playMouseSound() {
        val mediaPlayer = MediaPlayer.create(this, R.raw.mouse_sound)
        mediaPlayer.start()
    }

    private fun updateHitCounter() {
        hitCounter.text = "Попаданий: $hits"
    }

    private fun finishGame() {
        if (isGameFinished) return
        isGameFinished = true

        val endTime = SystemClock.elapsedRealtime()
        val gameTime = (endTime - startTime) / 1000

        val accuracy = if (totalTaps > 0) (hits.toDouble() / totalTaps) * 100 else 0.0

        dbHelper.insertGameResult(totalTaps, hits, accuracy, gameTime)

        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        finishGame()
    }
}
