package com.example.netology
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class GameStatsActivity : AppCompatActivity() {
    private lateinit var dbHelper: GameStatsDatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_stats)

        dbHelper = GameStatsDatabaseHelper(this)
        val statsTextView = findViewById<TextView>(R.id.statsTextView)

        val gameResults = dbHelper.getLast10Games()
        val statsText = StringBuilder()

        gameResults.forEachIndexed { index, result ->
            statsText.append("Игра ${index + 1}:\n")
            statsText.append("Общее количество нажатий: ${result.totalTaps}\n")
            statsText.append("Попадания по мышкам: ${result.hits}\n")
            statsText.append("Точность: ${"%.2f".format(result.accuracy)}%\n")
            //statsText.append("Время игры: ${result.gameTime / 1000} секунд\n\n")
        }

        statsTextView.text = statsText.toString()
    }
}
